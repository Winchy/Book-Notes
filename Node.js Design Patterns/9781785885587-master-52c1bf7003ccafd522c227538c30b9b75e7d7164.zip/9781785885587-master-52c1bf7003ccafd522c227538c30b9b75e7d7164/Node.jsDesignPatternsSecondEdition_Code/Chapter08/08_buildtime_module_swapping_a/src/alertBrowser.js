"use strict";

module.exports = alert;
