"use strict";

const alert = require('./alertServer');
alert('Morning comes whether you set the alarm or not!');
