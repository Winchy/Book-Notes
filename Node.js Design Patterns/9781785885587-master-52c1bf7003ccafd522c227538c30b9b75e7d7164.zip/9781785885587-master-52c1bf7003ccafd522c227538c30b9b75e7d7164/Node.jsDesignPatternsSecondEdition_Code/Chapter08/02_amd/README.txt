This sample demonstrates how to load an UMD module using AMD in the browser.

First, install all dependencies with:
  npm install

Then open with a browser the files:
  using_amd.html
