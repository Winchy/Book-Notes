This example shows how to propagate errors with callbacks.

To run the example launch:

  node readJson
