"use strict";

const result = [1, 5, 7].map(element => element - 1);
console.log(result); // [0, 4, 6]
