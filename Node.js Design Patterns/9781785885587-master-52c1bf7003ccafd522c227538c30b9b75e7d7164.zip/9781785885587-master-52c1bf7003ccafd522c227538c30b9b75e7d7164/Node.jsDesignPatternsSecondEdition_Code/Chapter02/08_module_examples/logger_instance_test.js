"use strict";

const logger = require('./logger_instance');

logger.log('This is an informational message');
