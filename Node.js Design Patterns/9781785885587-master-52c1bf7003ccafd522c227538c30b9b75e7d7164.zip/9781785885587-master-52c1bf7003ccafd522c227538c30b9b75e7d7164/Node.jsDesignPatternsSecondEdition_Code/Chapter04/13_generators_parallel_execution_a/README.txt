This sample demonstrates how to run a set of tasks in parallel using
generator-based control flow.

To run the sample code first install the dependencies:
  npm install

Then execute the 'spider' module by providing a valid url (including the protocol)
  node index http://www.example.com

