This sample demonstrates how generators can be used as a control
flow mechanism.

To run the sample code issue the command:
  node clone

