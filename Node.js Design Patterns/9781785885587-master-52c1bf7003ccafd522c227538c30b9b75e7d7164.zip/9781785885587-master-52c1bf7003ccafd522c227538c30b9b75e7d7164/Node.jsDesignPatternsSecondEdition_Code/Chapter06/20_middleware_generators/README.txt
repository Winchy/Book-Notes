This example shows how use the middleware pattern with generators in a web app built with the Koa framework.
To run this example you need to install the dependencies with

  npm install

then you can start the server with

  node app

and access it with your browser on http://localhost:3000
Try to refresh the page several times very quickly to reach the rate limit error and display the error.
