This sample demonstrates a simple implementation of the Command pattern.

To install all the dependencies, run the following:
  npm install

To try the sample run:
  node server
  
Then:
  node command
