This example shows how to implement a set of composable factory functions using
the stampit module.

To run the example you first need to install the dependencies with:

  npm install
  
and then you will be able to launch:

  node game
