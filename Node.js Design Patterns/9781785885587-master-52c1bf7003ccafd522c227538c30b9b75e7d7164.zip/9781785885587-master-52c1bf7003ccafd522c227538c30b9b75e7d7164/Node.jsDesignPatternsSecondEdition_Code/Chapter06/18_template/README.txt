This sample demonstrates how to use the Template pattern to 
create different configuration managers supporting different file formats.

To install all the dependencies:
  npm install

To run the sample:
  node configTest
