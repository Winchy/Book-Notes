This example shows an implementation of a custom write stream.
To run the example you need to install the dependencies with

  npm install

and then you will be able to run

  node writeToFile
