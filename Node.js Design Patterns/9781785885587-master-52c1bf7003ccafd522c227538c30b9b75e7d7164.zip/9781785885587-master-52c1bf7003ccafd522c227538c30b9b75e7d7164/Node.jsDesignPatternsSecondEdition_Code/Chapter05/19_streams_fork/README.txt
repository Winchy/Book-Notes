This example shows how to fork a stream by piping a single Readable stream into 
multiple Writable streams. It will generate sha1 and md5 checksum files for a 
given input file.file

To run it you can launch:
  node generateHash <path>
