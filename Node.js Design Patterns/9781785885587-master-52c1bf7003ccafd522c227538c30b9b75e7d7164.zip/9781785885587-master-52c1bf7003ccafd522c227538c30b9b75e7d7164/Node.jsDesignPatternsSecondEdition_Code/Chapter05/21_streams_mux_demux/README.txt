This example shows how to multiplex and demultiplex several streams to and
from a single channel.channel

To run the example you need to run the server first with:

  node server
  
then, in another shell you can run the client with:

  node client generateData.js
