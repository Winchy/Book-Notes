This example implements a combined stream that is used to compress and encrypt a file.

To run the example you need to install the dependencies with:

  npm install

Then you can run:

  node archive mypassword /path/to/a/file.txt
