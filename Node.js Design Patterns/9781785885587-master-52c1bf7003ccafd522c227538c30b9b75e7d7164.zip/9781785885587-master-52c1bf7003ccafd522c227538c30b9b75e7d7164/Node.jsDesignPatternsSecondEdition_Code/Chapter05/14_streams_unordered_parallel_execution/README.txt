This example illustrates how to build a unordered parallel execution flow using streams.
To run this example you need to install the dependencies with:

  npm install

and then:

  node checkUrls urlList.txt
