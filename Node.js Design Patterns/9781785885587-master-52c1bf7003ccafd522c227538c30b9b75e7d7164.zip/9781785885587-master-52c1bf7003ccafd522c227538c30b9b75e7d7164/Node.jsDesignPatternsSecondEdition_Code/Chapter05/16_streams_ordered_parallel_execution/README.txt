This example illustrates how to build an ordered parallel execution flow using streams.
To run this example you need to install the dependencies with:

  npm install

and then:

  node checkUrls urlList.txt