This examples illustrates how to use streams to build a sequential execution process.
To run the example you need to install the dependencies with:

  npm install

and then you can run:

  node concat niceBook.txt part1.txt part2.txt part3.txt
