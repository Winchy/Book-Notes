"use strict";

const x = 22;
const y = 17;
const obj = { x, y };

console.log(obj);
